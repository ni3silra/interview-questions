package com.ni3.bankbook;

import com.ni3.users.UsersDao;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "BankBookView", urlPatterns = {"/BankBookView"})
public class BankBookView extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        HttpSession session = request.getSession();
        String un = (String) session.getAttribute("user");
        String pwd = (String) session.getAttribute("pass");
        if (un == null && pwd == null) {
            response.sendRedirect("UserLogin");
        }

        UsersDao ud = new UsersDao();
        String name = ud.authenticate(un, pwd).getName();
        int uid = ud.authenticate(un, pwd).getUid();



        try {
            out.println("<!doctype html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>My Account -- Ni3</title>");
            out.println("<link rel='stylesheet' href='styles.css' type='text/css' />");
            out.println("<link rel='stylesheet' type='text/css' href='tcal.css' />");
            out.println("<script type='text/javascript' src='tcal.js'></script>");
            out.println("<script language=\"JavaScript\">");
            RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/validate.js");
            dispatcher.include(request, response);
            out.println("function validation()");
            out.println("{");
            out.println("if(!validString(document.form1.categoryname,1,\"Invalid Category\",1))");
            out.println("return false;");
            out.println("return true;");
            out.println("}");
            out.println("</script>");

            out.println("</head>");
            out.println("<body bgcolor=\"whitesmoke\">");
            dispatcher = request.getRequestDispatcher("header2.html");
            dispatcher.include(request, response);
            out.println("<section id='body' class='width clear'>");
            dispatcher = request.getRequestDispatcher("sidebar.html");
            dispatcher.include(request, response);
            out.println("<section id='content' class='column-right'>");
            out.println("<article>");
            out.println("<div align=\"center\" >");
            out.println("<fieldset>");
            out.println(" <legend><h1><b>Bank Book</b></h1></legend><br><br>");
            out.println("<form name = \"BankBookForm\" method =\"post\" action= \"BankBookView?opn=show\"  onSubmit=\"return validate(this);\">");
            out.println("<table border = 1>");
            out.println("<input type=\"hidden\" name=\"uid\" value=" + uid + ">");
            out.println("<tr bgcolor=\"#BFA56B\">");
            out.println("<th >Bank Book</th>");
            out.println("<td ><b> From Date</font></b> <input type='text' name='sdate' class='tcal' value='02/01/2015' /></td>");
            out.println("<td><b>To Date</b><input type='text' name='edate' class='tcal'value='04/01/2015' /></td>");
            out.println("<th ><input type = \"submit\" value = \"Show\"/></th>");
            out.println("</tr>");
            out.println("<tr bgcolor=\"#A89979\">");
            out.println("<th >S.NO.</th>");
            out.println("<th >Date</th>");
            out.println("<th>Amount</th>");
            out.println("<th >Pay/Receive</th>");
            out.println("</tr>");
            String opn = request.getParameter("opn");
            if ("show".equals(opn)) {
                String edate = request.getParameter("edate");
                String sdate = request.getParameter("sdate");

                System.out.println("sdate" + sdate);
                System.out.println("edate" + edate);

                Bank_BookDao cbd = new Bank_BookDao();
                Bank_Book bb = new Bank_Book();
                sdate = cbd.convertDate(sdate);
                edate = cbd.convertDate(edate);
                ArrayList<Bank_Book> al = cbd.findAllDateWise(sdate, edate, uid);
                for (Bank_Book e : al) {
                    out.println("<tr bgcolor=\"#BFA56B\">");
                    out.println("<td >" + e.getAcid() + "</td>");
                    out.println("<td >" + e.getTran_date() + "</td>");
                    out.println("<td >" + e.getAmount() + "</td>");
                    out.println("<td >" + e.getOperation() + "</td>");
                    out.println("</tr>");
                }
                out.println("<tr bgcolor=\"#A8915E\">");
                out.println("<th colspan = 2>Closing Balance</th>");
                out.println("<th colspan = 2>" + cbd.closingBalance(uid) + "</th>");
                out.println("</tr>");


                System.out.println("sdate" + sdate);
                System.out.println("edate" + edate);
                System.out.println("closing" + cbd.closingBalance(uid));
                System.out.println("opn" + opn);
                System.out.println("acc" + bb.getAccount());



            }
//            out.println("<tr>");
//            out.println("<th colspan = 2>Closing Balance</th>");
//            out.println("<th colspan = 2>0.0</th>");
//            out.println("</tr>");

            out.println("</table>");
            out.println("</form>");
            out.println("</fieldset>");
            out.println("<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>");

            out.println("</div>");
            out.println("</article>");
            out.println("</section'>");
            out.println("</section'>");
            dispatcher = request.getRequestDispatcher("footer.html");
            dispatcher.include(request, response);
            out.println("</body>");
            out.println("</html>");

            out.close();
        } finally {
            out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}

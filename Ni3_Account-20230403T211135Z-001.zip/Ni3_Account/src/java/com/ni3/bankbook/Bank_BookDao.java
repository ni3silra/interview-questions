package com.ni3.bankbook;

import com.ni3.utilities.ConnectionPool;
import java.sql.*;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

// createDao
public class Bank_BookDao {

    public void create(Bank_Book bean) {
        ConnectionPool c = ConnectionPool.getInstance();
        c.initialize();
        Connection conn = c.getConnection();

        try {
            conn = c.getConnection();
            String sql = "insert into bank_book(account,tran_date,amount,userid,operation) values(?,?,?,?,?)";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, bean.getAccount());
            pstmt.setString(2, bean.getTran_date());
            pstmt.setDouble(3, bean.getAmount());
            pstmt.setInt(4, bean.getUserid());
            pstmt.setString(5, bean.getOperation());
            pstmt.executeUpdate();

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            c.putConnection(conn);
        }
    }// End of create Dao


// edit the data
 public void edit(Bank_Book bean) {
        ConnectionPool c = ConnectionPool.getInstance();
        c.initialize();
        Connection conn = c.getConnection();
        try {
            String sql = "Update bank_book set account=?,amount=?,tran_date=?,userid=?,operation=? where acid=?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
          
            pstmt.setString(1, bean.getAccount());
            pstmt.setDouble(2, bean.getAmount());
            pstmt.setString(3, bean.getTran_date());
            pstmt.setInt(4,bean.getUserid());
            pstmt.setString(5,bean.getOperation());
              pstmt.setInt(6, bean.getAcid());
            pstmt.executeUpdate();

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            c.putConnection(conn);
        }
    }// End editdDao

 // delete the data
    public void remove(int id) {
        ConnectionPool c = ConnectionPool.getInstance();
        c.initialize();
        Connection conn = c.getConnection();
        try {
            String sql = "delete from bank_book where acid= ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, id);
            pstmt.executeUpdate();

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            c.putConnection(conn);
        }
    }// End- deleteDao


// find the data
     public Bank_Book find(int id) {
        ConnectionPool c = ConnectionPool.getInstance();
        c.initialize();
        Connection conn = c.getConnection();
        Bank_Book bean = new Bank_Book();
        try {

            String sql = "Select * from bank_book where  acid =?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
            bean.setAccount(rs.getString("account"));
            bean.setTran_date(rs.getString("tran_date"));
            bean.setAmount(rs.getDouble("amount"));
            bean.setUserid(rs.getInt("userid"));
            bean.setOperation(rs.getString("operation"));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            c.putConnection(conn);
        }
        return bean;
    }// End-findDao



// start-findAll
     public ArrayList<Bank_Book> findAll() {
        ConnectionPool c = ConnectionPool.getInstance();
        c.initialize();
        Connection conn = c.getConnection();
      ArrayList<Bank_Book> al = new ArrayList<Bank_Book>();
        try {

            String sql = "Select * from Bank_Book ";
            PreparedStatement pstmt = conn.prepareStatement(sql);

            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
               Bank_Book bean =new Bank_Book();
                bean.setAcid(rs.getInt("acid"));
                bean.setAccount(rs.getString("Account"));
                bean.setTran_date(rs.getString("tran_date"));
                bean.setAmount(rs.getDouble("amount"));
                bean.setUserid(rs.getInt("userid"));
                bean.setOperation(rs.getString("operation"));
            al.add(bean);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            c.putConnection(conn);
        }
        return al;
    }//End-findAll


//Strat findAllDatWise
     public ArrayList<Bank_Book> findAllDateWise(String sdate, String edate,int userid) {
        ConnectionPool c = ConnectionPool.getInstance();
        c.initialize();
        Connection conn = c.getConnection();
        ArrayList<Bank_Book> al = new ArrayList<Bank_Book>();
        try {

            String sql = "SELECT *  from bank_book where  (tran_date between ? and ?) and (userid=?) ";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, sdate);
             pstmt.setString(2, edate);
              pstmt.setInt(3, userid);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Bank_Book bean = new Bank_Book();
                bean.setAcid(rs.getInt("acid"));
                bean.setAccount(rs.getString("account"));
                bean.setTran_date(rs.getString("tran_date"));
                bean.setAmount(rs.getDouble("amount"));
                bean.setUserid(rs.getInt("userid"));
                bean.setOperation(rs.getString("operation"));
                al.add(bean);
            }

        } catch (Exception e) {
            System.out.println("Exception " + e);
        } finally {
            c.putConnection(conn);
        }
        return al;
    }// End-findAllDateWise


 public double closingBalance(int userid) {
        ConnectionPool c = ConnectionPool.getInstance();
        c.initialize();
        Connection conn = c.getConnection();
        double d = 0;
        try {
            String sql = "select (Select sum(amount) as total__credit from bank_book b where userid=? and operation='Credit') - (select sum(amount) as total_debit from bank_book b where userid=? and operation='Debit') as ClosingBalance from dual";
             PreparedStatement pstmt = conn.prepareStatement(sql);
             pstmt.setInt(1, userid);
             pstmt.setInt(2, userid);
            ResultSet rs = pstmt.executeQuery();
           if (rs.next()) {
           d = rs.getDouble("ClosingBalance");
           }

        } catch (Exception e) {
            System.out.println("Exception " + e);
        } finally {
            c.putConnection(conn);
        }
        return d;
    }


 public static String convertDate(String date) {
        DateFormat df = new SimpleDateFormat("MM/dd/yyyy");
        String convertedDate = new String();

        DateFormat df1 = new SimpleDateFormat("yyyy-MM-dd");
        java.util.Date d = new java.util.Date();
        try {

            d = df.parse(date);
            convertedDate = df1.format(d);
        } catch (ParseException ex) {
        }
        return convertedDate;
    }




     public static void main(String[] args) {
        Bank_BookDao st = new Bank_BookDao();

//        Bank_Book sb = new Bank_Book(10, "Saving", "2015-08-12", 786464, 23556, "Credit");
//        st.create(sb);

        
//       Bank_Book sb = new Bank_Book(10,"Saving", "2009-08-12", 7864, 2352556, "Credit-Valid");
//        st.edit(sb);
         
        
 //       st.remove(1);



//         System.out.println(st.find(10).getAccount());
//          System.out.println(st.find(10).getTran_date());
//           System.out.println(st.find(10).getAmount());
//            System.out.println(st.find(10).getUserid());
//             System.out.println(st.find(10).getOperation());



//        ArrayList<Bank_Book> al = st.findAll();
//        for (Bank_Book s : al) {
//        System.out.println(s.getAcid());
//          }



//        ArrayList<Bank_Book> al = st.findAllDateWise("1984-02-23","2014-02-09",1001);
//        for (Bank_Book b : al){
//            System.out.println(b.getTran_date());
//            System.out.println(b.getAccount());
//           System.out.println(b.getOperation());
//            System.out.println(b.getAmount());
 //       }
        

         System.out.println(st.closingBalance(1001));


    }
}


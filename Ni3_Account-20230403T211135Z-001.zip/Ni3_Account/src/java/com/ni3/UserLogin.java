package com.ni3;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "UserLogin", urlPatterns = {"/UserLogin"})
public class UserLogin extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            out.println("<!doctype html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>My Account -- Ni3</title>");
            out.println("<link rel='stylesheet' href='styles.css' type='text/css' />");
            out.println("<script language=\"JavaScript\">");
            RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/validate.js");
            dispatcher.include(request, response);
            out.println("function validation()");
            out.println("{");
            out.println("if(!validString(document.form1.categoryname,1,\"Invalid Category\",1))");
            out.println("return false;");
            out.println("return true;");
            out.println("}");
            out.println("</script>");
            out.println("</head>");
            out.println("<body bgcolor=\"whitesmoke\">");
            dispatcher = request.getRequestDispatcher("header.html");
            dispatcher.include(request, response);
            out.println("<section id='body' class='width clear'>");
            out.println("<section id='content' class='column-right'>");
            out.println("<article>");
            out.println("<div align=\"center\" >");
            out.println("<fieldset>");
            out.println(" <legend><h2><b>User Login</b></h2></legend><br><br>");
            out.println("<form name=\"loginform\" method=\"post\" action=\"Authentication\" onSubmit=\"return validate(this);\">");
            out.println("<table> <tr> <td><h4>Username:</h4></td><td> <input type=\"text\" name=\"user\"/></td></tr>");
            out.println("<tr> <td><h4>Password:</h4></td><td>  <input type=\"password\" name=\"pass\" maxlength=\"8\"/></td></tr>");
            out.println("<tr><td><input type=\"submit\"  value=\"Submit\" width=\"40\" height=\"40\"></td>");
            out.println(" <td><input type=\"reset\" value=\"Clear Details\"/></td></tr></table>");
            //out.println("<tr><td colspan='1'><a href='Authentication' class='button' onClick='validate(this); return false;' >Login Account</a></td>");
            //out.println("   <td ><a href='UserRegistration' class='button button-reversed'>Sign Up</a></td></tr></table>");
            String msg = request.getParameter("msg");
            if (msg != null) {
                out.println("<font bgcolor=\"red\"><h3>Incorrect Username Or password<h3></font>");
            }
            out.println("<br><br><br><br><br><br>");
            out.println("</fieldset>");
            out.println("</div>");
            out.println("</article>");

            out.println("</section'>");

            out.println("</section'>");

            dispatcher = request.getRequestDispatcher("footer.html");
            dispatcher.include(request, response);

            out.println("</body>");
            out.println("</html>");

        } finally {
            out.close();
        }

    }

// <editor-fold defaultstate="collapsed" desc="comment">
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }
}// </editor-fold>


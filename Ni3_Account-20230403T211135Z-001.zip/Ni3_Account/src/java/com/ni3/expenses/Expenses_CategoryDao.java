package com.ni3.expenses;

import com.ni3.utilities.ConnectionPool;
import java.sql.*;
import java.util.*;

public class Expenses_CategoryDao {

    public void create(Expenses_Category bean) {
        ConnectionPool c = ConnectionPool.getInstance();
        c.initialize();
        Connection conn = c.getConnection();

         try {
            conn = c.getConnection();
            String sql = "Insert into expenses_category (exp_catname,exp_catdetails,userid) values(?,?,?)";
            PreparedStatement pstmt = conn.prepareStatement(sql);
          //  pstmt.setInt(1, bean.getExp_catid());
            pstmt.setString(1, bean.getExp_catname());
            pstmt.setString(2, bean.getExp_catdetails());
          pstmt.setInt(3, bean.getUserid());
            pstmt.executeUpdate();

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            c.putConnection(conn);
        }
    }



 public void edit(Expenses_Category bean) {
        ConnectionPool c = ConnectionPool.getInstance();
        c.initialize();
        Connection conn = c.getConnection();
        try {
            String sql = "Update Expenses_Category set exp_catname=?,exp_catdetails=?,userid=? where exp_catid=?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, bean.getExp_catname());
            pstmt.setString(2, bean.getExp_catdetails());
            pstmt.setInt(3, bean.getUserid());
            pstmt.setInt(4, bean.getExp_catid());
            pstmt.executeUpdate();

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            c.putConnection(conn);
        }
    }

    public void remove(int id) {
        ConnectionPool c = ConnectionPool.getInstance();
        c.initialize();
        Connection conn = c.getConnection();
        try {
            String sql = "delete from Expenses_Category where exp_catid= ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, id);
            pstmt.executeUpdate();

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            c.putConnection(conn);
        }
    }

     public Expenses_Category find(int id) {
        ConnectionPool c = ConnectionPool.getInstance();
        c.initialize();
        Connection conn = c.getConnection();
        Expenses_Category bean = new Expenses_Category();
        try {

            String sql = "Select * from Expenses_Category where  exp_catid =?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
           bean.setExp_catid(rs.getInt("exp_catid"));
                bean.setExp_catname(rs.getString("exp_catname"));
                bean.setExp_catdetails(rs.getString("exp_catdetails"));
                bean.setUserid(rs.getInt("userid"));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            c.putConnection(conn);
        }
        return bean;
    }

     public ArrayList<Expenses_Category> findAll() {
        ConnectionPool c = ConnectionPool.getInstance();
        c.initialize();
        Connection conn = c.getConnection();
      ArrayList<Expenses_Category> al = new ArrayList<Expenses_Category>();
        try {

            String sql = "Select * from Expenses_Category ";
            PreparedStatement pstmt = conn.prepareStatement(sql);

            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
               Expenses_Category bean =new Expenses_Category();
                bean.setExp_catid(rs.getInt("exp_catid"));
                bean.setExp_catname(rs.getString("exp_catname"));
                bean.setExp_catdetails(rs.getString("exp_catdetails"));
                bean.setUserid(rs.getInt("userid"));
            al.add(bean);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            c.putConnection(conn);
        }
        return al;
    }

public ArrayList<Expenses_Category> findAll(int userid) {
        ConnectionPool c = ConnectionPool.getInstance();
        c.initialize();
        Connection conn = c.getConnection();
      ArrayList<Expenses_Category> al = new ArrayList<Expenses_Category>();
      Expenses_Category bean =new Expenses_Category();
        try {

            String sql = "Select * from Expenses_Category where userid=? ";
            PreparedStatement pstmt = conn.prepareStatement(sql);
             pstmt.setInt(1, userid);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {

                bean.setExp_catid(rs.getInt("exp_catid"));
                bean.setExp_catname(rs.getString("exp_catname"));
                bean.setExp_catdetails(rs.getString("exp_catdetails"));
                bean.setUserid(rs.getInt("userid"));
            al.add(bean);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            c.putConnection(conn);
        }
        return al;
    }



      public static void main(String[] args) {
        Expenses_CategoryDao st = new Expenses_CategoryDao();


        st.remove(5);

//      Expenses_Category sb = new Expenses_Category(1256, "Saving", "hii", 2036);
//      st.create(sb);


     //  Expenses_Category sb = new Expenses_Category(1265, "Saving", "hiihg", 2036);
   //    st.edit(sb);


   //     st.remove(1265);


   //       System.out.println(st.find(1256).getExp_catdetails());



//        ArrayList<Expenses_Category> al = st.findAll(2036);
//        for (Expenses_Category s : al) {
//        System.out.println(s.getExp_catdetails());
//        }
//
}
}


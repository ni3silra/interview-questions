package com.ni3.expenses;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "ExpCatUpdateRequest", urlPatterns = {"/ExpCatUpdateRequest"})
public class ExpCatUpdateRequest extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        int id = 0;
        System.out.println(id);

        String exp_catname = request.getParameter("exp_catname");
        String exp_catdetails = request.getParameter("exp_catdetails");
        String uid = request.getParameter("uid");
        int userid = Integer.parseInt(uid);
        Expenses_Category ec = new Expenses_Category();
        try {


            id = Integer.parseInt(request.getParameter("exp_catid"));
            if (id != 0) {

                ec.setExp_catid(id);
                ec.setExp_catname(exp_catname);
                ec.setExp_catdetails(exp_catdetails);
                ec.setUserid(userid);
            } else {

                response.sendRedirect("ExpensesCategory");
            }

            System.out.println(exp_catname);
            System.out.println(exp_catdetails);
            Expenses_CategoryDao ecd = new Expenses_CategoryDao();

            ecd.edit(ec);
            response.sendRedirect("ExpensesCategory");

        } finally {
            out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}

package com.ni3.expenses;

import com.ni3.users.UsersDao;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "ExpensesSubmitRequest", urlPatterns = {"/ExpensesSubmitRequest"})
public class ExpensesSubmitRequest extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        HttpSession session = request.getSession();
        String un = (String) session.getAttribute("user");
        String pwd = (String) session.getAttribute("pass");
        if (un == null && pwd == null) {
            response.sendRedirect("UserLogin");
        }

        UsersDao ud = new UsersDao();
        String name = ud.authenticate(un, pwd).getName();
        int uid = ud.authenticate(un, pwd).getUid();






        String expense = request.getParameter("expense");
        int category = Integer.parseInt(request.getParameter("category"));
        double amount = Double.parseDouble(request.getParameter("amount"));

        String payby = request.getParameter("payby");
        String remark = request.getParameter("remark");
        String date = request.getParameter("sdate");
        ExpensesDao ed = new ExpensesDao();
        Expenses e = new Expenses();
        String cdate = ed.convertDate(date);

        try {
            System.out.println("expense---" + expense);
            System.out.println("category---" + category);
            System.out.println("amount---" + amount);
            System.out.println("payby---" + payby);
            System.out.println("remark---" + remark);
            System.out.println("date--" + cdate);
            e.setExp_ac(expense);
            e.setExp_catid(category);
            e.setAmount(amount);
            e.setPayby(payby);
            e.setRemark(remark);
            e.setTran_date(cdate);
            e.setUserid(uid);
            ed.create(e);
            response.sendRedirect("ExpensesSubmit?msg=incorrect");
        } finally {
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}

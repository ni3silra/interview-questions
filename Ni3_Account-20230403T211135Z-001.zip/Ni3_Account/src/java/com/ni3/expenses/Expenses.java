
package com.ni3.expenses;

public class Expenses {

    int exp_id;
    String exp_ac;
    int userid;
    int exp_catid;
    double amount;
    String tran_date;
    String payby;
    String remark;

    public Expenses(int exp_id, String exp_ac, int userid, int exp_catid, double amount, String tran_date, String payby, String remark) {
        this.exp_id = exp_id;
        this.exp_ac = exp_ac;
        this.userid = userid;
        this.exp_catid = exp_catid;
        this.amount = amount;
        this.tran_date = tran_date;
        this.payby = payby;
        this.remark = remark;
    }

    public Expenses(String exp_ac, int userid, int exp_catid, double amount, String tran_date, String payby, String remark) {
        this.exp_ac = exp_ac;
        this.userid = userid;
        this.exp_catid = exp_catid;
        this.amount = amount;
        this.tran_date = tran_date;
        this.payby = payby;
        this.remark = remark;
    }

    public Expenses() {
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getExp_ac() {
        return exp_ac;
    }

    public void setExp_ac(String exp_ac) {
        this.exp_ac = exp_ac;
    }

    public int getExp_catid() {
        return exp_catid;
    }

    public void setExp_catid(int exp_catid) {
        this.exp_catid = exp_catid;
    }

    public int getExp_id() {
        return exp_id;
    }

    public void setExp_id(int exp_id) {
        this.exp_id = exp_id;
    }

    public String getPayby() {
        return payby;
    }

    public void setPayby(String payby) {
        this.payby = payby;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getTran_date() {
        return tran_date;
    }

    public void setTran_date(String tran_date) {
        this.tran_date = tran_date;
    }

    public int getUserid() {
        return userid;
    }

    public void setUserid(int userid) {
        this.userid = userid;
    }



}

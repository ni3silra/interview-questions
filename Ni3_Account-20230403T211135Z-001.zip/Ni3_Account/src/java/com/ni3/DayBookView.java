package com.ni3;

import com.ni3.expenses.Expenses;
import com.ni3.expenses.ExpensesDao;
import com.ni3.incomes.Incomes;
import com.ni3.incomes.IncomesDao;
import com.ni3.users.UsersDao;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "DayBookView", urlPatterns = {"/DayBookView"})
public class DayBookView extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        HttpSession session = request.getSession();
        String un = (String) session.getAttribute("user");
        String pwd = (String) session.getAttribute("pass");
        if (un == null && pwd == null) {
            response.sendRedirect("UserLogin");
        }

        UsersDao ud = new UsersDao();
        String name = ud.authenticate(un, pwd).getName();
        int uid = ud.authenticate(un, pwd).getUid();
        System.out.println(un);
        System.out.println(pwd);


        try {
            out.println("<!doctype html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>My Account -- Ni3</title>");
            out.println("<link rel='stylesheet' href='styles.css' type='text/css' />");
            out.println("<link rel='stylesheet' type='text/css' href='tcal.css' />");
            out.println("<script type='text/javascript' src='tcal.js'></script>");
            out.println("<script language=\"JavaScript\">");
            RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/validate.js");
            dispatcher.include(request, response);
            out.println("function validation()");
            out.println("{");
            out.println("if(!validString(document.form1.categoryname,1,\"Invalid Category\",1))");
            out.println("return false;");
            out.println("return true;");
            out.println("}");
            out.println("</script>");

            out.println("</head>");
            out.println("<body bgcolor=\"whitesmoke\">");
            dispatcher = request.getRequestDispatcher("header2.html");
            dispatcher.include(request, response);
            out.println("<section id='body' class='width clear'>");
            dispatcher = request.getRequestDispatcher("sidebar.html");
            dispatcher.include(request, response);

            out.println("<section id='content' class='column-right'>");
            out.println("<article>");
            out.println("<div align=\"center\" >");
            out.println("<fieldset>");
            out.println(" <legend><h1><b>Day Book</b></h1></legend><br><br>");

            out.println("<form name =\"myform\" method =\"post\" action= \"DayBookView?opn=show\"  onSubmit=\"return validate(this);\">");
            out.println("<table border = 1>");


            out.println("<tr bgcolor=\"#BFA56B\">");
            out.println("<th colspan=\"1\">Day Book </th>");
            out.println("<td colspan=\"4\"><b> From Date</font></b> <input type='text' name='sdate' class='tcal' value='02/01/2015' /></td>");
            out.println("<td colspan=\"4\"><b>To Date</b><input type='text' name='edate' class='tcal' value='04/01/2015' /></td>");
            out.println("<th colspan=\"1\"><input type =\"submit\" value =\"SHOW\" /></th></tr>");


            out.println("<tr bgcolor=\"#A89979\" >");
            out.println("<th colspan=\"1\">S.NO.</th>");
            out.println("<th colspan=\"2\">Account	 Name</th>");
            out.println("<th colspan=\"2\">Date</th>");
            out.println("<th colspan=\"2\">Amount</th>");
            out.println("<th colspan=\"2\">Pay/ReciveBy</th>");
            out.println("<th colspan=\"1\">Remark</th></tr>");
            String opn = request.getParameter("opn");
            if ("show".equals(opn)) {
                String edate = request.getParameter("edate");
                String sdate = request.getParameter("sdate");

                ExpensesDao cbd = new ExpensesDao();
                sdate = cbd.convertDate(sdate);
                edate = cbd.convertDate(edate);
                out.println("<th colspan=\"10\" bgcolor=\"#A89979\">Expenses</th></tr>");

                ArrayList<Expenses> al = cbd.findAllDateWise(sdate, edate, uid);
                for (Expenses e : al) {
                    out.println("<tr bgcolor=\"#BFA56B\">");
                    out.println("<td colspan=\"1\">" + e.getExp_id() + "</td>");
                    out.println("<td colspan=\"2\">" + e.getExp_ac() + "</td>");
                    out.println("<td colspan=\"2\">" + e.getTran_date() + "</td>");
                    out.println("<td colspan=\"2\">" + e.getAmount() + "</td>");
                    out.println("<td colspan=\"2\">" + e.getPayby() + "</td>");
                    out.println("<td colspan=\"1\">" + e.getRemark() + "</td></tr>");
                }



                out.println("<th colspan=\"10\" bgcolor=\"#A89979\">Incomes</th></tr>");
                IncomesDao ebd = new IncomesDao();
                ArrayList<Incomes> bl = ebd.findAllDateWise(sdate, edate, uid);
                for (Incomes i : bl) {
                    out.println("<tr bgcolor=\"#BFA56B\">");
                    out.println("<td colspan=\"1\">" + i.getInc_id() + "</td>");
                    out.println("<td colspan=\"2\">" + i.getInc_ac() + "</td>");
                    out.println("<td colspan=\"2\">" + i.getTran_date() + "</td>");
                    out.println("<td colspan=\"2\">" + i.getAmount() + "</td>");
                    out.println("<td colspan=\"2\">" + i.getReciveby() + "</td>");
                    out.println("<td colspan=\"1\">" + i.getRemark() + "</td></tr>");
                }
            }


            out.println("</table>");
            out.println("</form>");

            out.println("<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>");
            out.println("</fieldset>");
            out.println("</div>");
            out.println("</article>");
            out.println("</section'>");
            out.println("</section'>");
            dispatcher = request.getRequestDispatcher("footer.html");
            dispatcher.include(request, response);
            out.println("</body>");
            out.println("</html>");
        } finally {
            out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}

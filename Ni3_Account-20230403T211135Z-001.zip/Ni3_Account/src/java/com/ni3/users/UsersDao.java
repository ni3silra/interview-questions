package com.ni3.users;

import com.ni3.utilities.ConnectionPool;
import java.sql.*;
import java.util.*;

public class UsersDao {

    public void create(Users bean) {
        ConnectionPool c = ConnectionPool.getInstance();
        c.initialize();
        Connection conn = c.getConnection();

        try {
            conn = c.getConnection();
            String sql = "Insert into users (username,password,name,address,mobile,email) values(?,?,?,?,?,?)";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, bean.getUsername());
            pstmt.setString(2, bean.getPassword());
            pstmt.setString(3, bean.getName());
            pstmt.setString(4, bean.getAddress());
            pstmt.setString(5, bean.getMobile());
            pstmt.setString(6, bean.getEmail());

            pstmt.executeUpdate();

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            c.putConnection(conn);
        }
    }

    public void edit(Users bean) {
        ConnectionPool c = ConnectionPool.getInstance();
        c.initialize();
        Connection conn = c.getConnection();
        try {
            String sql = "update users set password=?,name=?,address=?,mobile=?,email=? where uid=?";
            PreparedStatement pstmt = conn.prepareStatement(sql);

         //   pstmt.setString(1, bean.getUsername());
            pstmt.setString(1, bean.getPassword());
            pstmt.setString(2, bean.getName());
            pstmt.setString(3, bean.getAddress());
            pstmt.setString(4, bean.getMobile());
            pstmt.setString(5, bean.getEmail());
            pstmt.setInt(6, bean.getUid());
            pstmt.executeUpdate();

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            c.putConnection(conn);
        }
    }

    public void remove(int id) {
        ConnectionPool c = ConnectionPool.getInstance();
        c.initialize();
        Connection conn = c.getConnection();
        try {
            String sql = "delete from users where uid= ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, id);
            pstmt.executeUpdate();

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            c.putConnection(conn);
        }
    }

    public Users find(int id) {
        ConnectionPool c = ConnectionPool.getInstance();
        c.initialize();
        Connection conn = c.getConnection();
        Users bean = new Users();
        try {

            String sql = "Select * from users where uid =?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                bean.setUid(rs.getInt("uid"));
                bean.setUsername(rs.getString("username"));
                bean.setPassword(rs.getString("password"));
                bean.setName(rs.getString("name"));
                bean.setAddress(rs.getString("address"));
                bean.setMobile(rs.getString("mobile"));
                bean.setEmail(rs.getString("email"));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            c.putConnection(conn);
        }
        return bean;
    }

    public int checkAvailability(String uname) {
        ConnectionPool c = ConnectionPool.getInstance();
        c.initialize();
        Connection conn = c.getConnection();
        //    Users bean = new Users();
        String name = new String();
        int a = 0;
        try {

            String sql = "Select username from users ";
            PreparedStatement pstmt = conn.prepareStatement(sql);

            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {

                name = rs.getString("username");
                if (uname.equals(name)) {
                    a = 1;
                    break;
                } else {
                    a = 2;
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            c.putConnection(conn);
        }
        return a;
    }

    public int checkAvailability(String uname, String pass) {
        ConnectionPool c = ConnectionPool.getInstance();
        c.initialize();
        Connection conn = c.getConnection();
        //    Users bean = new Users();
        String name = new String();
        String pwd = new String();
        int a = 0;
        try {
            String sql = "Select uid,username,password from users ";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                name = rs.getString("username");
                pwd = rs.getString("password");
                if (name.equals(uname)) {
                    if (pass.equals(pwd)) {
                        a = rs.getInt("uid");
                        break;
                    }
                } 
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            c.putConnection(conn);
        }
        return a;
    }



    public ArrayList<Users> findAll() {
        ConnectionPool c = ConnectionPool.getInstance();
        c.initialize();
        Connection conn = c.getConnection();
        ArrayList<Users> al = new ArrayList<Users>();
        try {

            String sql = "Select * from users ";
            PreparedStatement pstmt = conn.prepareStatement(sql);

            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Users bean = new Users();
                bean.setUid(rs.getInt("uid"));
                bean.setUsername(rs.getString("username"));
                bean.setPassword(rs.getString("password"));
                bean.setName(rs.getString("name"));
                bean.setAddress(rs.getString("address"));
                bean.setMobile(rs.getString("mobile"));
                bean.setEmail(rs.getString("email"));
                al.add(bean);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            c.putConnection(conn);
        }
        return al;
    }






    public Users authenticate(String uname,String pass) {
        ConnectionPool c = ConnectionPool.getInstance();
        c.initialize();
        Connection conn = c.getConnection();
        Users bean = new Users();
        UsersDao ud = new UsersDao();
        try {
               int a = ud.checkAvailability(uname, pass);
            String sql = "Select * from users where uid =?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, a);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                bean.setUid(rs.getInt("uid"));
                bean.setUsername(rs.getString("username"));
                bean.setPassword(rs.getString("password"));
                bean.setName(rs.getString("name"));
                bean.setAddress(rs.getString("address"));
                bean.setMobile(rs.getString("mobile"));
                bean.setEmail(rs.getString("email"));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            c.putConnection(conn);
        }
        return bean;
    }



public static void main(String[] args) {
        UsersDao ud = new UsersDao();

//       Users ub = new Users("Ni3kl","ni3","Nitin","bhopal","9898989898","silra@ni3silra.com");
//      ud.create(ub);
//


//        Users ub = new Users(1,"ni3silra","ni3","Nitin","bhopal","9898989898","silra@ni3.com");
//        ud.edit(ub);
//         System.out.println(ud.find("ni3silra"));
//System.out.println(ud.checkAvailability("lokesh"));

       System.out.println(ud.checkAvailability("Nitin", "123456"));

 //   System.out.println(ud.authenticate("lokesh", "lks").getAddress());

    }
}

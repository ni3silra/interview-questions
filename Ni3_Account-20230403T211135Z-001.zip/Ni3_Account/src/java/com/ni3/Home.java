package com.ni3;

import com.ni3.users.UsersDao;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "Home", urlPatterns = {"/Home"})
public class Home extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
         HttpSession session = request.getSession();
        String un = (String) session.getAttribute("user");
        String pwd = (String) session.getAttribute("pass");
        if (un == null && pwd == null) {
            response.sendRedirect("UserLogin");
        }

        UsersDao ud = new UsersDao();
       String name = ud.authenticate(un, pwd).getName();
       int uid = ud.authenticate(un, pwd).getUid();
        System.out.println(un);
        System.out.println(pwd);

        try {
            out.println("<!doctype html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>My Account -- Ni3</title>");
            out.println("<link rel='stylesheet' href='styles.css' type='text/css' />");
            out.println("<script language=\"JavaScript\">");
            RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/validate.js");
            dispatcher.include(request, response);
            out.println("function validation()");
            out.println("{");
            out.println("if(!validString(document.form1.categoryname,1,\"Invalid Category\",1))");
            out.println("return false;");
            out.println("return true;");
            out.println("}");
            out.println("</script>");
            out.println("</head>");
            out.println("<body bgcolor=\"whitesmoke\">");
            dispatcher = request.getRequestDispatcher("header2.html");
            dispatcher.include(request, response);
            out.println("<section id='body' class='width clear'>");
            dispatcher = request.getRequestDispatcher("sidebar.html");
            dispatcher.include(request, response);

            out.println("<section id='content' class='column-right'>");
            out.println("<article>");
            out.println("<div align=\"center\" >");
            out.println("<fieldset>");
            out.println(" <legend><h1><b>User Profile</b></h1></legend><br><br>");


            out.println("<h1>Welcome " + name + "</h1>");
            out.println("<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>");
            out.println("</fieldset>");
            out.println("</div>");
            out.println("</article>");

            out.println("</section'>");

            out.println("</section'>");

            dispatcher = request.getRequestDispatcher("footer.html");
            dispatcher.include(request, response);
            out.println("</body>");
            out.println("</html>");

        } finally {
            out.close();
        }

    }

// <editor-fold defaultstate="collapsed" desc="comment">
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }
}// </editor-fold>


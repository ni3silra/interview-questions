package com.ni3.cashbook;


import com.ni3.utilities.ConnectionPool;
import java.sql.*;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class Cash_BookDao {

    // <editor-fold defaultstate="collapsed" desc="comment">
    public void create(Cash_Book bean) {
        ConnectionPool c = ConnectionPool.getInstance();
        c.initialize();
        Connection conn = c.getConnection();

        try {
            conn = c.getConnection();
            String sql = "Insert into cash_book (acid,account,tran_date,amount,userid,operation) values(?,?,?,?,?,?)";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, bean.getAcid());
            pstmt.setString(2, bean.getAccount());
            pstmt.setString(3, bean.getTran_date());
            pstmt.setDouble(4, bean.getAmount());
            pstmt.setInt(5, bean.getUserid());
            pstmt.setString(6, bean.getOperation());
            pstmt.executeUpdate();

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            c.putConnection(conn);
        }
    }// </editor-fold>


    // <editor-fold defaultstate="collapsed" desc="comment">
    public void edit(Cash_Book bean) {
        ConnectionPool c = ConnectionPool.getInstance();
        c.initialize();
        Connection conn = c.getConnection();
        try {
            String sql = "Update cash_book set account=?,amount=?,tran_date=?,userid=?,operation=? where acid=?";
            PreparedStatement pstmt = conn.prepareStatement(sql);

            pstmt.setString(1, bean.getAccount());
            pstmt.setDouble(2, bean.getAmount());
            pstmt.setString(3, bean.getTran_date());
            pstmt.setInt(4, bean.getUserid());
            pstmt.setString(5, bean.getOperation());
            pstmt.setInt(6, bean.getAcid());
            pstmt.executeUpdate();

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            c.putConnection(conn);
        }
    }// </editor-fold>



    // <editor-fold defaultstate="collapsed" desc="comment">
    public void remove(int id) {
        ConnectionPool c = ConnectionPool.getInstance();
        c.initialize();
        Connection conn = c.getConnection();
        try {
            String sql = "delete from cash_book where acid= ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, id);
            pstmt.executeUpdate();

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            c.putConnection(conn);
        }
    }// </editor-fold>



     // <editor-fold defaultstate="collapsed" desc="comment">
    public Cash_Book find(int id) {
        ConnectionPool c = ConnectionPool.getInstance();
        c.initialize();
        Connection conn = c.getConnection();
        Cash_Book bean = new Cash_Book();
        try {

            String sql = "Select * from cash_book where  acid =?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                bean.setAccount(rs.getString("account"));
                bean.setTran_date(rs.getString("tran_date"));
                bean.setAmount(rs.getDouble("amount"));
                bean.setUserid(rs.getInt("userid"));
                bean.setOperation(rs.getString("operation"));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            c.putConnection(conn);
        }
        return bean;
    }// </editor-fold>



     // <editor-fold defaultstate="collapsed" desc="comment">
    public ArrayList<Cash_Book> findAll() {
        ConnectionPool c = ConnectionPool.getInstance();
        c.initialize();
        Connection conn = c.getConnection();
        ArrayList<Cash_Book> al = new ArrayList<Cash_Book>();
        try {

            String sql = "Select * from cash_Book ";
            PreparedStatement pstmt = conn.prepareStatement(sql);

            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Cash_Book bean = new Cash_Book();
                bean.setAcid(rs.getInt("acid"));
                bean.setAccount(rs.getString("Account"));
                bean.setTran_date(rs.getString("tran_date"));
                bean.setAmount(rs.getDouble("amount"));
                bean.setUserid(rs.getInt("userid"));
                bean.setOperation(rs.getString("operation"));
                al.add(bean);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            c.putConnection(conn);
        }
        return al;
    }// </editor-fold>


     public ArrayList< Cash_Book > findAllDateWise(String sdate, String edate,int userid) {
        ConnectionPool c = ConnectionPool.getInstance();
        c.initialize();
        Connection conn = c.getConnection();
        ArrayList<Cash_Book> al = new ArrayList<Cash_Book>();
        try {

            String sql = "SELECT *  from cash_book where  (tran_date between ? and ?) and (userid=?) ";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, sdate);
             pstmt.setString(2, edate);
              pstmt.setInt(3, userid);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Cash_Book bean = new Cash_Book();
                bean.setAcid(rs.getInt("acid"));
                bean.setAccount(rs.getString("account"));
                bean.setTran_date(rs.getString("tran_date"));
                bean.setAmount(rs.getDouble("amount"));
                bean.setUserid(rs.getInt("userid"));
                bean.setOperation(rs.getString("operation"));
                al.add(bean);
            }

        } catch (Exception e) {
            System.out.println("Exception " + e);
        } finally {
            c.putConnection(conn);
        }
        return al;
    }


public double closingBalance(int userid) {
        ConnectionPool c = ConnectionPool.getInstance();
        c.initialize();
        Connection conn = c.getConnection();
        double d = 0;
        try {
            String sql = "select (Select sum(amount) as total__credit from cash_book b where userid=? and operation='Credit') - (select sum(amount) as total_debit from cash_book b where userid=? and operation='Debit') as ClosingBalance from dual";
             PreparedStatement pstmt = conn.prepareStatement(sql);
             pstmt.setInt(1, userid);
             pstmt.setInt(2, userid);
            ResultSet rs = pstmt.executeQuery();
           if (rs.next()) {
           d = rs.getDouble("ClosingBalance");
           }

        } catch (Exception e) {
            System.out.println("Exception " + e);
        } finally {
            c.putConnection(conn);
        }
        return d;
    }


 public static String convertDate(String date) {
         DateFormat df = new SimpleDateFormat("MM/dd/yyyy");
       String convertedDate = new String();

        DateFormat df1 = new SimpleDateFormat("yyyy-MM-dd");
        java.util.Date d = new java.util.Date();
        try {

            d = df.parse(date);
            convertedDate = df1.format(d);
        } catch (ParseException ex) {
        }
        return convertedDate;
    }





      public static void main(String[] args) {
        Cash_BookDao st = new Cash_BookDao();

          // <editor-fold defaultstate="collapsed" desc="comment">
//          Cash_Book sb = new Cash_Book(2, "extern", "2015-02-12", 256895652, 20365, "debit");
//          st.create(sb);


      //  Cash_Book sb = new Cash_Book(1, "Saving", "2017-03-14", 256895652, 20365, "Debit");
      //  st.edit(sb);
         
      
    //    st.remove(1);
      
      //    System.out.println(st.find(1).getAccount());



       /* ArrayList<Cash_Book> al = st.findAll();
        for (Cash_Book s : al) {
        System.out.println(s.getAccount());
        }
 */

//       ArrayList<Cash_Book> al = st.findAllDateWise("1984-02-23","2016-02-09",20365);
//        for (Cash_Book b : al){
//            System.out.println(b.getTran_date());
//            System.out.println(b.getAccount());
//           System.out.println(b.getOperation());
//        System.out.println(b.getAmount());
//        }
       
            System.out.println(st.closingBalance(20365));
}
}


package com.ni3.incomes;

import com.ni3.users.UsersDao;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "IncomeSubmit", urlPatterns = {"/IncomeSubmit"})
public class IncomeSubmit extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        HttpSession session = request.getSession();
        String un = (String) session.getAttribute("user");
        String pwd = (String) session.getAttribute("pass");
        if (un == null && pwd == null) {
            response.sendRedirect("UserLogin");
        }

        UsersDao ud = new UsersDao();
        String name = ud.authenticate(un, pwd).getName();
        int uid = ud.authenticate(un, pwd).getUid();


        try {

            out.println("<!doctype html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>My Account -- Ni3</title>");
            out.println("<link rel='stylesheet' href='styles.css' type='text/css' />");
            out.println("<link rel='stylesheet' type='text/css' href='tcal.css' />");
            out.println("<script type='text/javascript' src='tcal.js'></script>");
            out.println("<script language=\"JavaScript\">");
            RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/validate.js");
            dispatcher.include(request, response);
            out.println("function validation()");
            out.println("{");
            out.println("if(!validString(document.form1.categoryname,1,\"Invalid Category\",1))");
            out.println("return false;");
            out.println("return true;");
            out.println("}");
            out.println("</script>");
            out.println("</head>");
            out.println("<body bgcolor=\"whitesmoke\">");
            dispatcher = request.getRequestDispatcher("header2.html");
            dispatcher.include(request, response);
            out.println("<section id='body' class='width clear'>");
            dispatcher = request.getRequestDispatcher("sidebar.html");
            dispatcher.include(request, response);

            out.println("<section id='content' class='column-right'>");
            out.println("<article>");
            out.println("<div align=\"center\" >");
            out.println("<fieldset>");
            out.println(" <legend><h1><b>Income</b></h1></legend><br><br>");
          String msg = request.getParameter("msg");
            if (msg != null) {
                out.println("<I><h5>Income Successfully Added</h5></I>");
            }

            out.println("<form name=\"addincform\" method=\"post\" action=\"IncomeSubmitRequest\" onSubmit=\"return validate(this);\">");
            out.println("<table> <tr> <td> Income: </td>  <td> <input type=\"text\" name=\"income\"/></td></tr>");
            out.println("<tr> <td>Category:</td><td><select name=\"category\">");
            Income_CategoryDao cdao = new Income_CategoryDao();
            ArrayList<Income_Category> al = cdao.findAll();
            for (Income_Category bean : al) {
                out.println("<option value=" + bean.getInc_catid() + ">" + bean.getInc_catname() + "</option>");
            }
            out.println("</select></td></tr>");
            out.println("<tr><td>Amount:</td><td><input type=\"text\" name=\"amount\" /></td></tr>");
            out.println("<tr> <td>Recieve By: </td><td><select name=\"recieveby\">");
            out.println("<option value=\"Cash\"> Cash </option>");
            out.println("<option value=\"Cheque\"> Cheque </option>");
            out.println("<option value=\"ATM\"> ATM  </option>");
            out.println("<option value=\"Online\"> Online  </option></select></td></tr>");
            out.println("<tr> <td>Remark: </td>    <td>  <input type=\"text\" name=\"remark\" /></td></tr>");
            out.println("<tr> <td>Date:   </td>    <td>   <input type='text' name='sdate' class='tcal' value='' /></td></tr></table><br/>");
            out.println("<tr> <td>&nbsp;</td>  <td><input type=\"submit\"  value=\"Submit\" width=\"20\" height=\"20\"></td>");
            out.println(" <td>&nbsp;</td>    <td><input type=\"reset\" value=\"Clear Details\"/></td></tr></table>");
            out.println("</fieldset>");
            out.println("</div>");
            out.println("</article>");
            out.println("</section'>");
            out.println("</section'>");
            dispatcher = request.getRequestDispatcher("footer.html");
            dispatcher.include(request, response);
            out.println("</body>");
            out.println("</html>");




        } finally {
            out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}

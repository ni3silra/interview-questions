package com.ni3.incomes;

import com.ni3.users.UsersDao;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name="IncomeCategoryUpdate", urlPatterns={"/IncomeCategoryUpdate"})
public class IncomeCategoryUpdate extends HttpServlet {
   
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

             HttpSession session = request.getSession();
        String un = (String) session.getAttribute("user");
        String pwd = (String) session.getAttribute("pass");
        if (un == null && pwd == null) {
            response.sendRedirect("UserLogin");
        }

        UsersDao ud = new UsersDao();
       String name = ud.authenticate(un, pwd).getName();
//       int uid = ud.authenticate(un, pwd).getUid();

        try {
       String a = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\">";
            out.println(a);
            out.println("<html>");
            out.println("<head>");
            out.println("<script language=\"JavaScript\">");
            RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/validate.js");
            dispatcher.include(request, response);
            out.println("function validation()");
            out.println("{");
            out.println("if(!validString(document.form1.categoryname,1,\"Invalid Category\",1))");
            out.println("return false;");
            out.println("return true;");
            out.println("}");
            out.println("</script>");
            out.println("<title>Ni3 Account</title>");
            dispatcher = request.getRequestDispatcher("/design/stylesheet.html");
            dispatcher.include(request, response);
            out.println("</head>");
            out.println("<body>");
            dispatcher = request.getRequestDispatcher("/design/header1.html");
            dispatcher.include(request, response);
            out.println("<div align=\"center\" >");
            out.println("<fieldset>");
            out.println(" <legend><h1><b>Income Categories</b></h1></legend><br><br>");
              int id = Integer.parseInt(request.getParameter("id"));
        Income_CategoryDao icd = new Income_CategoryDao();
        Income_Category  ic =   icd.find(id);
            out.println("<form name=\"inccataddform\" method=\"post\" action=\"IncCatUpdateRequest\" onSubmit=\"return validate(this);\">");
        out.println("<input type=\"hidden\" name=\"inc_catid\" value="+id+">");

            out.println("<table> <tr> <td colspan=\"3\"> <h2>Category Name:</h2> </td>    <td colspan=\"2\"> <input type=\"text\" name=\"inc_catname\" value="+ic.getInc_catname() +" /></td></tr>");
        out.println("<table> <tr> <td colspan=\"3\"> <h2>Category Details:</h2> </td>    <td colspan=\"2\"> <input type=\"text\" name=\"inc_catdetails\" value=" + ic.getInc_catdetails() + " /></td></tr>");
     out.println("<tr> <td colspan=\"3\">&nbsp;</td>  <td><input type=\"submit\"  value=\"Update Details\" width=\"20\" height=\"20\"></td>");
            out.println("   <td colspan=\"2\"><input type=\"reset\" value=\"Clear Details\"/></td></tr></table>");
   
//            out.println("<div id=\"\">");
//            out.println("<table cellspacing=\"3\" border=\"2\" ><tr><th colspan=\"3\"><h2>Category Name</h2></th><th colspan=\"3\"><h2>Catgeory Deatils</h2></th>");
//            out.println("<th colspan=\"3\"><h2>Edit</h2></th><th colspan=\"3\"><h2>Delete</h2></th></tr>");
//            out.println("</div>");
//            Income_CategoryDao cd = new Income_CategoryDao();
//            ArrayList<Income_Category> list = cd.findAll();
//            for (Income_Category bean : list) {
//                out.println("<tr>");
//                out.println("<td colspan=\"3\"><h3>" + bean.getInc_catname() + "</h3></td>");
//               out.println("<td colspan=\"3\"><h3>" + bean.getInc_catdetails() + "</h3></td>");
//                out.println("<td colspan=\"3\"><a href=\"IncomeCategoryUpdate?id=" + bean.getInc_catid() + "\">Edit</a></td>");
//               out.println("<td colspan=\"3\"><a href=\"IncomeCategoryRemove?id=" + bean.getInc_catid() + "\">Delete</a></td>");
//                out.println("</tr>");
//            }
//            out.println("<table>");
            out.println("<div><br><br><br><br><br><br><br><br><br></div>");

            out.println("</fieldset>");
            dispatcher = request.getRequestDispatcher("/design/footer.html");
            dispatcher.include(request, response);
            out.println("</body>");
            out.println("</html>");
   } finally { 
            out.close();
        }
    } 

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    } 

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

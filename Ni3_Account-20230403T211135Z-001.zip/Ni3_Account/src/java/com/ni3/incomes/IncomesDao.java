package com.ni3.incomes;

import com.ni3.utilities.ConnectionPool;
import java.sql.*;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class IncomesDao {

    public void create(Incomes bean) {
        ConnectionPool c = ConnectionPool.getInstance();
        c.initialize();
        Connection conn = c.getConnection();

         try {
            conn = c.getConnection();
            String sql = "Insert into Incomes (inc_ac,userid,inc_catid,amount,tran_date,reciveby,remark) values(?,?,?,?,?,?,?)";
            PreparedStatement pstmt = conn.prepareStatement(sql);
         
            pstmt.setString(1, bean.getInc_ac());
            pstmt.setInt(2, bean.getUserid());
            pstmt.setInt(3, bean.getInc_catid());
            pstmt.setDouble(4, bean.getAmount());
            pstmt.setString(5, bean.getTran_date());
            pstmt.setString(6, bean.getReciveby());
            pstmt.setString(7, bean.getRemark());
            pstmt.executeUpdate();

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            c.putConnection(conn);
        }
    }



 public void edit(Incomes bean) {
        ConnectionPool c = ConnectionPool.getInstance();
        c.initialize();
        Connection conn = c.getConnection();
        try {
            String sql = "Update Incomes set inc_ac=?,userid=?,inc_catid=?,amount=?,tran_date=?,reciveby=?,remark=? where inc_id=?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(7, bean.getRemark());
            pstmt.setString(1, bean.getInc_ac());
            pstmt.setInt(2, bean.getUserid());
            pstmt.setInt(3, bean.getInc_catid());
            pstmt.setDouble(4, bean.getAmount());
            pstmt.setString(5, bean.getTran_date());
            pstmt.setString(6, bean.getReciveby());
            pstmt.setInt(8, bean.getInc_id());
            pstmt.executeUpdate();

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            c.putConnection(conn);
        }
    }

    public void remove(int id) {
        ConnectionPool c = ConnectionPool.getInstance();
        c.initialize();
        Connection conn = c.getConnection();
        try {
            String sql = "delete from Incomes where inc_id= ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, id);
            pstmt.executeUpdate();

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            c.putConnection(conn);
        }
    }

     public Incomes find(int id) {
        ConnectionPool c = ConnectionPool.getInstance();
        c.initialize();
        Connection conn = c.getConnection();
        Incomes  bean = new Incomes();
        try {

            String sql = "Select * from Incomes where  inc_id =?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
             bean.setInc_id(rs.getInt("Inc_id"));
            bean.setInc_ac(rs.getString("Inc_ac"));
            bean.setUserid(rs.getInt("userid"));
            bean.setInc_catid(rs.getInt("Inc_catid"));
            bean.setAmount(rs.getDouble("amount"));
            bean.setTran_date(rs.getString("tran_date"));
            bean.setReciveby(rs.getString("reciveby"));
            bean.setRemark(rs.getString("remark"));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            c.putConnection(conn);
        }
        return bean;
    }

     public ArrayList<Incomes> findAll() {
        ConnectionPool c = ConnectionPool.getInstance();
        c.initialize();
        Connection conn = c.getConnection();
      ArrayList<Incomes> al = new ArrayList<Incomes>();
        try {

            String sql = "Select * from Incomes ";
            PreparedStatement pstmt = conn.prepareStatement(sql);

            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
               Incomes bean =new Incomes();
                bean.setInc_id(rs.getInt("inc_id"));
                bean.setInc_ac(rs.getString("inc_ac"));
                bean.setUserid(rs.getInt("userid"));
                bean.setInc_catid(rs.getInt("inc_catid"));
                bean.setAmount(rs.getDouble("amount"));
                bean.setTran_date(rs.getString("tran_date"));
                bean.setReciveby(rs.getString("reciveby"));
                bean.setRemark(rs.getString("remark"));
            al.add(bean);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            c.putConnection(conn);
        }
        return al;
    }



     public ArrayList<Incomes> findAll(int userid) {
        ConnectionPool c = ConnectionPool.getInstance();
        c.initialize();
        Connection conn = c.getConnection();
      ArrayList<Incomes> al = new ArrayList<Incomes>();
        try {
               Incomes bean = new Incomes();
            String sql = "Select * from Incomes where userid=?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
                pstmt.setInt(1, userid);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                bean.setInc_id(rs.getInt("Inc_id"));
                bean.setInc_ac(rs.getString("Inc_ac"));
                bean.setUserid(rs.getInt("userid"));
                bean.setInc_catid(rs.getInt("Inc_catid"));
                bean.setAmount(rs.getDouble("amount"));
                bean.setTran_date(rs.getString("tran_date"));
                bean.setReciveby(rs.getString("reciveby"));
                bean.setRemark(rs.getString("remark"));
            al.add(bean);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            c.putConnection(conn);
        }
        return al;
    }



      public ArrayList<Incomes> findAllDateWise(String sdate, String edate,int userid) {
        ConnectionPool c = ConnectionPool.getInstance();
        c.initialize();
        Connection conn = c.getConnection();
        ArrayList<Incomes> al = new ArrayList<Incomes>();
        try {

            String sql = "SELECT *  from Incomes where  (tran_date between ? and ?) and (userid=?) ";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, sdate);
             pstmt.setString(2, edate);
              pstmt.setInt(3, userid);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Incomes bean = new Incomes();
                 bean.setInc_id(rs.getInt("Inc_id"));
                bean.setInc_ac(rs.getString("Inc_ac"));
                bean.setUserid(rs.getInt("userid"));
                bean.setInc_catid(rs.getInt("Inc_catid"));
                bean.setAmount(rs.getDouble("amount"));
                bean.setTran_date(rs.getString("tran_date"));
                bean.setReciveby(rs.getString("reciveby"));
                bean.setRemark(rs.getString("remark"));
                al.add(bean);
            }

        } catch (Exception e) {
            System.out.println("Exception " + e);
        } finally {
            c.putConnection(conn);
        }
        return al;
    }

 public static String convertDate(String date) {
        DateFormat df = new SimpleDateFormat("MM/dd/yyyy");
        String convertedDate = new String();

        DateFormat df1 = new SimpleDateFormat("yyyy-MM-dd");
        java.util.Date d = new java.util.Date();
        try {

            d = df.parse(date);
            convertedDate = df1.format(d);
        } catch (ParseException ex) {
        }
        return convertedDate;
    }



      public static void main(String[] args) {
        IncomesDao st = new IncomesDao();

//        Incomes sb = new Incomes(3, "CurrentSaving", 2037, 58, 708589562,"2105-3-05", "abhishek", "good");
//        st.create(sb);

//        Incomes sb = new Incomes(1, "Saving", 2035, 56,905689562,"2017-3-15", "abhi", "goodbad");
//        st.edit(sb);
        
    
   //     st.remove(3);

 //         System.out.println(st.find(1).getRemark());

        
//        ArrayList<Incomes> al = st.findAll(2035);
//        for (Incomes s : al) {
//        System.out.println(s.getRemark());
//        }


        ArrayList<Incomes> al = st.findAllDateWise("1984-02-23","2024-02-09",0);
            for (Incomes b : al){
            System.out.println(b.getAmount());
            System.out.println(b.getInc_ac());
        }
}
}


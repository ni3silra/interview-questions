package com.ni3.incomes;

import com.ni3.utilities.ConnectionPool;
import java.sql.*;
import java.util.*;

public class Income_CategoryDao {

    public void create(Income_Category bean) {
        ConnectionPool c = ConnectionPool.getInstance();
        c.initialize();
        Connection conn = c.getConnection();

         try {
            conn = c.getConnection();
            String sql = "Insert into income_category (inc_catid,inc_catname,inc_catdetails,userid) values(?,?,?,?)";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, bean.getInc_catid());
            pstmt.setString(2, bean.getInc_catname());
            pstmt.setString(3, bean.getInc_catdetails());
            pstmt.setInt(4, bean.getUserid());
            pstmt.executeUpdate();

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            c.putConnection(conn);
        }
    }



 public void edit(Income_Category bean) {
        ConnectionPool c = ConnectionPool.getInstance();
        c.initialize();
        Connection conn = c.getConnection();
        try {
            String sql = "Update Income_Category set inc_catname=?,inc_catdetails=?,userid=? where inc_catid=?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, bean.getInc_catname());
            pstmt.setString(2, bean.getInc_catdetails());
            pstmt.setInt(3, bean.getUserid());
            pstmt.setInt(4, bean.getInc_catid());
            pstmt.executeUpdate();

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            c.putConnection(conn);
        }
    }

    public void remove(int id) {
        ConnectionPool c = ConnectionPool.getInstance();
        c.initialize();
        Connection conn = c.getConnection();
        try {
            String sql = "delete from Income_Category where inc_catid= ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, id);
            pstmt.executeUpdate();

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            c.putConnection(conn);
        }
    }

     public Income_Category find(int id) {
        ConnectionPool c = ConnectionPool.getInstance();
        c.initialize();
        Connection conn = c.getConnection();
        Income_Category bean = new Income_Category();
        try {

            String sql = "Select * from Income_Category where  inc_catid =?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
           bean.setInc_catid(rs.getInt("inc_catid"));
                bean.setInc_catname(rs.getString("inc_catname"));
                bean.setInc_catdetails(rs.getString("inc_catdetails"));
                bean.setUserid(rs.getInt("userid"));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            c.putConnection(conn);
        }
        return bean;
    }

     public ArrayList<Income_Category> findAll() {
        ConnectionPool c = ConnectionPool.getInstance();
        c.initialize();
        Connection conn = c.getConnection();
      ArrayList<Income_Category> al = new ArrayList<Income_Category>();
        try {

            String sql = "Select * from Income_Category ";
            PreparedStatement pstmt = conn.prepareStatement(sql);

            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
               Income_Category bean =new Income_Category();
                bean.setInc_catid(rs.getInt("inc_catid"));
                bean.setInc_catname(rs.getString("inc_catname"));
                bean.setInc_catdetails(rs.getString("inc_catdetails"));
                bean.setUserid(rs.getInt("userid"));
            al.add(bean);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            c.putConnection(conn);
        }
        return al;
    }

public ArrayList<Income_Category> findAll(int userid) {
        ConnectionPool c = ConnectionPool.getInstance();
        c.initialize();
        Connection conn = c.getConnection();
      ArrayList<Income_Category> al = new ArrayList<Income_Category>();
      Income_Category bean =new Income_Category();
        try {

            String sql = "Select * from Income_Category where userid=? ";
            PreparedStatement pstmt = conn.prepareStatement(sql);
             pstmt.setInt(1, userid);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {

                bean.setInc_catid(rs.getInt("Inc_catid"));
                bean.setInc_catname(rs.getString("Inc_catname"));
                bean.setInc_catdetails(rs.getString("Inc_catdetails"));
                bean.setUserid(rs.getInt("userid"));
            al.add(bean);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            c.putConnection(conn);
        }
        return al;
    }



      public static void main(String[] args) {
        Income_CategoryDao st = new Income_CategoryDao();

  //     Income_Category sb = new Income_Category(1256, "Saving", "hii", 2036);
   //    st.create(sb);


     //  Income_Category sb = new Income_Category(1265, "Saving", "hiihg", 2036);
   //    st.edit(sb);
         
        
   //     st.remove(1265);


   //       System.out.println(st.find(1256).getInc_catdetails());


        
//        ArrayList<Income_Category> al = st.findAll(2036);
//        for (Income_Category s : al) {
//        System.out.println(s.getInc_catdetails());
//        }
//
}
}

